import * as DELETEBook from '../requests/DELETEBook.request'
import * as GETBook from '../requests/GETBook.request'
import * as POSTBooks from '../requests/POSTBook.request'


describe('DELETE Books', () => {
    it('Deletar um livro', ()=> {
        GETBook.allBooks().then((resALLBooks) => {
            //cy.log(resALLBooks.body[0].id)
            DELETEBook.deleteBook(resALLBooks.body[0].id).should((resDeleteBook) => {
                expect(resDeleteBook.status).to.eq(200)
            })
        })

    })
    it('Criar e excluir um livro', () => {
        POSTBooks.addBook().then((resAddBook) => {
            DELETEBook.deleteBook(resAddBook.body.id).should((resDeleteBook) => {
                expect(resDeleteBook.status).to.eq(200)
            })
        })
    })
})