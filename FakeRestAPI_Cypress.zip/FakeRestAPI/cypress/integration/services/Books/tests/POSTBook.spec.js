/// <reference types="cypress" />
import * as POSTBook from '../requests/POSTBook.request'

describe('POST Books', ()=> {
    it('Adicionar um novo livro', ()=> {
        POSTBook.addBook().should((response) => {
            expect(response.status).to.eq(200)
            expect(response.body.title).to.eq("Nov de 63")
        })
    })
})