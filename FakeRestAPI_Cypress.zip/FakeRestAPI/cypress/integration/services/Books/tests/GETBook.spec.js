/// <reference types="cypress" />
import * as GETBook from '../requests/GETBook.request'

describe ('GET Books', () => {
    it('Listar todos os livros', () => {
        GETBook.allBooks().should((response) => {
            //cy.log(response.status)
            //cy.log(response.statusText)
            //cy.log(response.body)

            expect(response.status).to.eq(200)
            expect(response.body).to.be.not.null
        })
    })
})